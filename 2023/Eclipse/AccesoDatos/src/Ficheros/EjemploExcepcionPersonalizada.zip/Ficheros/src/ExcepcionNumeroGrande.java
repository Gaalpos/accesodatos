
public class ExcepcionNumeroGrande extends Exception{

	public ExcepcionNumeroGrande(String mensaje) {
		super(mensaje);
	}
}
