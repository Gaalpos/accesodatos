/**
 * 
 */
/**
 * 
 */
module jdbc {
	requires java.desktop;
	requires mysql.connector.j;
	requires java.sql;
}